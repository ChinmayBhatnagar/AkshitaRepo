\
/* Parallax scroll for elements with data-speed */
const parallaxEls = [...document.querySelectorAll('[data-speed]')];
function onScroll(){
  const y = window.scrollY;
  parallaxEls.forEach(el=>{
    const speed = parseFloat(el.dataset.speed || '0.2');
    el.style.transform = `translate3d(0, ${y * speed * -0.3}px, 0)`;
  });
}
onScroll();
addEventListener('scroll', onScroll, {passive:true});

/* Subtle 3D tilt on gallery cards */
document.querySelectorAll('[data-tilt]').forEach(card=>{
  card.addEventListener('mousemove', e=>{
    const r = card.getBoundingClientRect();
    const x = ((e.clientX - r.left)/r.width - .5) * 8;
    const y = ((e.clientY - r.top)/r.height - .5) * -8;
    card.style.transform = `rotateX(${y}deg) rotateY(${x}deg) translateY(-6px)`;
  });
  card.addEventListener('mouseleave', ()=> card.style.transform = '');
});

/* Typewriter for love letter */
const typed = document.getElementById('typed');
if(typed){
  const text = `Being with you feels like sunrise after a long night. 
I love the way you laugh, the way you listen, and the way you make every ordinary moment extraordinary.
Thank you for choosing me—today and always. ♡`;
  let i = 0;
  const type = () => {
    if(i <= text.length){
      typed.textContent = text.slice(0, i++);
      setTimeout(type, 28);
    } else {
      typed.style.borderRight = '2px solid transparent';
    }
  };
  setTimeout(type, 600);
}

/* Soft background music (user gesture required) */
const audio = document.getElementById('bgm');
const btn = document.getElementById('music-toggle');
if(btn && audio){
  let playing = false;
  btn.addEventListener('click', async ()=>{
    try{
      if(!playing){ await audio.play(); playing = true; btn.textContent='❚❚'; }
      else { audio.pause(); playing = false; btn.textContent='♪'; }
    }catch(e){ console.log(e); }
  });
}
